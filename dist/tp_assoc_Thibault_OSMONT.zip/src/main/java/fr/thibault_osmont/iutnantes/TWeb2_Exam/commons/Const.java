package fr.thibault_osmont.iutnantes.TWeb2_Exam.commons;

public class Const {

	public final static String COMMANDE = "commande" ;
	public final static String ADHERENT = "adherent" ;
	
	public final static String LISTE_ARTICLES = "listeArticles" ;
	public final static String LISTE_ADHERENTS = "listeAdherents" ;
	
	public final static String LISTE_PAYS = "listePays" ;

	//Variables rajoutées
	public final static String SESSION_USER = "user";
}
